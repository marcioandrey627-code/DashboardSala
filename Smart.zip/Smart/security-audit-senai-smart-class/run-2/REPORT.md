# Relatório de pentest ativo controlado - SENAI Smart Class

**Alvo:** https://smart-sala.vercel.app/  
**Data:** 31/10/2026 (America/Sao_Paulo)  
**Tipo:** avaliação externa ativa, não destrutiva, sem credenciais.

## Resultado executivo

Nenhuma vulnerabilidade crítica, alta ou média foi confirmada durante a cobertura pública sem autenticação. Foram testados cabeçalhos, CORS, métodos, reflexão de XSS, arquivos sensíveis, traversal codificado, endpoints comuns, chamadas sem JWT às Edge Functions e acesso anônimo às tabelas expostas pelo Supabase.

Há uma pendência de hardening: `senai-login` e `senai-admin` aceitam duas origens confiáveis em CORS: `smart-sala.vercel.app` e `senai-smart-class-one.vercel.app`. A origem legada aparenta ser outra publicação do mesmo aplicativo e devolve cabeçalhos equivalentes. Ela deve permanecer no allowlist somente se ainda estiver sob controle e for necessária.

## Evidências ativas

| Controle | Resultado |
| --- | --- |
| Página pública e headers | HTTP 200 com CSP, HSTS, X-Frame-Options DENY, nosniff, COOP, Referrer-Policy e Permissions-Policy. |
| XSS refletido por query string | A resposta para payload SVG codificado teve o mesmo SHA-256 da página normal; não houve reflexão. |
| Arquivos sensíveis | `/.env` e `/.git/HEAD` retornaram 404. |
| Rotas comuns | `/api`, `/admin` e `/login` não expuseram endpoint aplicacional. |
| Traversal codificado | Duas variantes de `../etc/passwd` retornaram 400. |
| Método POST no site estático | Retornou 405. OPTIONS retornou 204 sem permitir origem externa. |
| RLS/API anônima | HEAD autenticado apenas com chave publishable retornou 401 Bearer para `profiles`, `rooms`, `sensor_readings` e `system_events`. Nenhum registro foi solicitado ou exibido. |
| `senai-admin` sem JWT | POST `action:list` retornou 401. |
| `senai-login` com entrada vazia | Retornou 400 com erro genérico `invalid_input`; não houve enumeração de usuário. |
| CORS das funções | Domínio atual e domínio legado: 204 e origem explícita. `evil.example`: 403. |

## Pendência de hardening

**CORS-LEGACY-ORIGIN - allowlist inclui domínio legado.** Não é uma vulnerabilidade confirmada porque o domínio legado responde como SENAI Smart Class e aparenta ser controlado pelo mesmo proprietário. Remover `https://senai-smart-class-one.vercel.app` das Edge Functions se ele não for mais necessário; caso permaneça, manter deploy, DNS e acesso ao projeto Vercel sob controle estrito.

## Limites obrigatórios

Não foram executados DoS, scans de portas na infraestrutura compartilhada da Vercel, força bruta, credential stuffing, persistência, escrita de dados, leitura de registros, exploração pós-acesso ou testes de sessão autenticada. Isso evita impacto ao serviço e a dados pessoais.

Para fechar cobertura de RLS, IDOR, RBAC, exportação, gestão de contas, tokens, logout e rate limit, são necessárias contas descartáveis de ALUNO, PROFESSOR e ADM em homologação, além de autorização explícita para o projeto Supabase de teste.

## Próximas ações

1. Confirmar a necessidade e a propriedade do domínio legado no allowlist CORS.
2. Criar contas descartáveis e executar uma matriz de privilégios por papel.
3. Validar RLS com `USING` e `WITH CHECK` para sala, autor e eventos de auditoria.
4. Testar bloqueio de login e recuperação de sessão em homologação, sem usar contas reais.
5. Adicionar verificações pós-deploy para CORS, headers e commit publicado.
