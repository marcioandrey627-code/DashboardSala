# Arquitetura e limites da revisão

O SENAI Smart Class é um painel estático HTML, CSS e JavaScript publicado na Vercel. O navegador carrega o SDK Supabase UMD com versão e SRI fixados, usa Supabase Auth para criar uma sessão e consulta o banco Supabase diretamente para telemetria e eventos. A interface implementa os papéis `ALUNO`, `PROFESSOR` e `ADM`; somente os dois últimos podem operar o painel, e somente `ADM` expõe operações de gestão de contas.

Os principais limites de confiança são: navegador não autenticado -> Edge Function `senai-login`; sessão autenticada -> tabela `profiles`; usuário de operação -> `rooms`, `sensor_readings` e `system_events`; e administrador -> Edge Function `senai-admin`. O frontend aplica esses papéis para UX, mas ele não é uma fronteira de segurança: usuários podem modificar JavaScript no próprio navegador. A fronteira efetiva deve estar nas políticas RLS e nas Edge Functions, que não foram fornecidas.

Entradas relevantes: e-mail e senha de login; respostas das funções Supabase; dados de perfis, telemetria e eventos devolvidos pelo banco; formulário administrativo; datas de exportação; e transcrição de voz. A maior parte do conteúdo dinâmico é renderizada com `textContent`; o único `innerHTML` achado cria uma árvore de elementos constante, sem interpolação de entrada externa.

A configuração local prevê CSP, HSTS, `X-Frame-Options`, `nosniff`, `Referrer-Policy`, `Permissions-Policy` e COOP. A presença desses arquivos não prova que o domínio publicado está vinculado a este diretório ou que a configuração foi aplicada ao deployment atual. Não foi localizado histórico de auditoria compatível; o diretório revisado estava não rastreado no repositório Git de trabalho.

Esta execução não fez requisições ao domínio público, não usou credenciais nem executou `npm test`, pois as regras da revisão exigem isolamento de processo/rede que não está disponível aqui. O resultado é uma revisão estática parcial e não uma certificação do ambiente publicado.
