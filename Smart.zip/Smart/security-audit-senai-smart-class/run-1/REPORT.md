# Relatório de segurança - SENAI Smart Class

**Data:** 31/10/2026  
**Alvo informado:** https://smart-sala.vercel.app/  
**Método:** revisão estática parcial do diretório `Smart-sala-main` e de sua configuração local.  
**Status:** incompleto para fins de pentest de produção. Não foram enviados ataques, varreduras, logins ou requisições ao site público.

## Resumo executivo

Não foi confirmada vulnerabilidade explorável a partir do código disponibilizado. O frontend apresenta boas práticas relevantes: CSP declarada, dependência Supabase com versão e SRI fixados, renderização dinâmica predominantemente via `textContent`, limpeza de sessão local, interface por papéis e páginas de erro genéricas.

Entretanto, as quatro fronteiras de maior risco - gestão de usuários, isolamento de telemetria, rate limit de login e cabeçalhos do deployment - dependem de componentes não incluídos: políticas RLS, Edge Functions Supabase e estado da Vercel. Elas são leads priorizados para validação controlada; não têm severidade atribuída porque a evidência disponível não demonstra falha.

## Escopo e cobertura

Revisados: `index.html`, `senai-auth.js`, `app.js`, `theme-init.js`, `vercel.json`, manifestos npm, documentação e testes locais. Não revisados: código das Edge Functions, migrations/RLS, segredos, logs, configuração Supabase/Vercel, DNS, WAF/CDN, contas e dados de produção. O diretório do projeto estava não rastreado no repositório Git de trabalho; portanto não há um commit específico do sistema revisado que possa ser atestado.

## Diagnóstico por domínio

### Autenticação

O formulário chama `senai-login` em vez de autenticar diretamente no navegador. A interface trata bloqueio de tentativa e evita persistência de sessão (`persistSession: false`). A efetividade do rate limit, contudo, precisa ser observada na Edge Function e em sua camada de armazenamento.

### Autorização e administração

`isAdmin()` e `canOperatePanel()` são controles de interface. Eles melhoram a experiência, mas não podem ser considerados autorização contra um usuário que controle o navegador. `senai-admin` deve verificar JWT, status e papel no servidor para cada ação, inclusive create, update e list.

### Dados de telemetria

O cliente consulta uma sala nomeada e restringe a leitura por `room_id`; ao gravar, envia `created_by`. Isso é positivo como limitação de aplicação, mas não impede uma chamada REST modificada. RLS deve impor escopo de sala e `created_by = auth.uid()` de forma independente do cliente.

### XSS e conteúdo no navegador

As listas de contas e textos dinâmicos utilizam `textContent`. O único `innerHTML` localizado em `app.js` cria marcação literal fixa para o widget de voz, sem interpolar usuário, banco ou fala reconhecida. Não foi encontrada evidência estática de DOM XSS nessa superfície. `style-src 'unsafe-inline'` permanece uma concessão de hardening por causa de estilos dinâmicos; não é achado confirmado sem uma injeção de HTML/estilo alcançável.

### Cabeçalhos e cadeia de suprimentos

`vercel.json` declara CSP, HSTS, `nosniff`, `X-Frame-Options: DENY`, COOP e Permissions-Policy. `index.html` referencia o SDK Supabase 2.57.0 com SRI SHA-384 e `crossorigin=anonymous`. A configuração local é consistente com os testes, mas somente o deployment pode confirmar a entrega real dos cabeçalhos e do bundle.

### Privacidade e governança

O próprio aviso de privacidade informa que controlador, encarregado, canal de atendimento, bases legais e retenção ainda precisam ser formalizados. Trate isso como pendência de governança/LGPD, não como uma vulnerabilidade técnica confirmada.

## Leads que requerem validação

| Prioridade operacional | Lead | Bloqueio |
| --- | --- | --- |
| 1 | RBAC da Edge Function `senai-admin` | Fonte e testes do backend ausentes |
| 2 | RLS de `profiles`, `rooms`, `sensor_readings` e `system_events` | Migrations e políticas ausentes |
| 3 | Rate limit e CORS de `senai-login` | Fonte, logs e ambiente de homologação ausentes |
| 4 | Cabeçalhos e versão de `smart-sala.vercel.app` | Estado da Vercel não observado |

Os detalhes estruturados estão em `findings.json`. Nenhum item da tabela é vulnerabilidade confirmada e nenhum recebeu CVSS/severidade.

## Recomendações

1. Versione, no repositório privado com acesso controlado, migrations RLS, testes de políticas e código das Edge Functions; mantenha uma cópia sanitizada para auditorias.
2. Crie quatro contas descartáveis de homologação (anônima, aluno, professor e administrador) e automatize uma matriz de permissões para cada tabela e função.
3. Na Edge Function administrativa, derive identidade e papel exclusivamente do JWT validado no servidor; ignore papel, usuário-alvo e qualquer decisão de privilégio recebida do navegador, salvo parâmetros explicitamente permitidos.
4. Em RLS, verifique tanto o `USING` quanto o `WITH CHECK`, sobretudo para `room_id`, `created_by` e registros de auditoria imutáveis.
5. Confirme, por release, os cabeçalhos reais e o commit implantado. Registre essa checagem no pipeline de deploy.
6. Formalize retenção, finalidade, papéis de privacidade e canal de atendimento antes de tratar o painel como produção com dados pessoais.

## Próximo ciclo de validação

Execute os planos de `findings.json` apenas em homologação autorizada e com dados/contas descartáveis. Anexe ao próximo relatório: versão da Edge Function, export das RLS, resultado da matriz de permissões, evidência de rate limit e captura dos cabeçalhos do deployment. Só então será possível classificar impacto e severidade de eventuais falhas.
