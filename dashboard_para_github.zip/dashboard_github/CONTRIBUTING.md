# Como colaborar com o projeto

## Antes de começar

1. Leia o `README.md` e execute o dashboard localmente.
2. Confira as **Issues** abertas para evitar trabalho duplicado.
3. Discuta a tarefa com a equipe antes de fazer mudanças maiores.

## Fluxo de alteração

1. Crie uma branch a partir de `main`, por exemplo `feat/melhorar-graficos` ou `fix/alerta-luminosidade`.
2. Faça alterações pequenas e claras, mantendo HTML, CSS e JS em arquivos separados.
3. Teste no navegador usando Live Server.
4. Abra um **Pull Request** explicando o que mudou e como testar.
5. Peça a outro integrante para revisar antes de integrar à `main`.

## Como escrever uma boa Issue

- **Problema ou melhoria:** o que precisa ser feito?
- **Local:** em qual aba ou arquivo?
- **Passos:** como reproduzir, se for um erro?
- **Resultado esperado:** o que deveria acontecer?
- **Evidências:** captura de tela sem dados pessoais, quando necessário.

## Checklist de Pull Request

- [ ] Testei a página inicial e as três abas.
- [ ] Testei atualização e modo automático, quando alterados.
- [ ] Não criei links quebrados para CSS ou JavaScript.
- [ ] Atualizei o README se o funcionamento mudou.
- [ ] Não incluí senhas, tokens ou informações pessoais.

## Convenções

Use nomes de funções e variáveis descritivos; evite mudanças sem relação com a tarefa. Documente especialmente a mudança de regras em `aplicarAutomacao()` e de estrutura de dados em `estado`.
